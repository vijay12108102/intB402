﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospitalManagement
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Department dm = new Department();
            dm.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Patient pt = new Patient();
            pt.Show();
        }

       

        private void button3_Click_1(object sender, EventArgs e)
        {
            Doctor dr = new Doctor();
            dr.Show();

        }
    }
}
