﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace hospitalManagement
{
    public partial class Doctor : Form
    {
        public Doctor()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into doctab values(@doctorid,@doctorname,@experience,@phone)", con);
            cmd.Parameters.AddWithValue("@DoctorID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@DoctorName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Experience", textBox3.Text);
            cmd.Parameters.AddWithValue("@Phone", textBox4.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Saved Sucessfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from doctab", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update doctab where doctorname=@doctorname,experience=@experience,phone=@phone where doctorID=@doctorid", con);
            cmd.Parameters.AddWithValue("@doctorID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@doctorName", textBox2.Text);
            cmd.Parameters.AddWithValue("@experience", textBox3.Text);
            cmd.Parameters.AddWithValue("@phone", textBox4.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record updated Sucessfully");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete doctab where doctorid=@doctorid", con);
            cmd.Parameters.AddWithValue("@doctorID", int.Parse(textBox1.Text));
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record deleted Sucessfully");
        }

        private void Doctor_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from doctab", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
