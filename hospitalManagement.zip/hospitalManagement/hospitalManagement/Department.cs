﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;


namespace hospitalManagement
{
    public partial class Department : Form
    {
        public Department()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into deptab values(@deptid,@deptname,@phone)", con);
            cmd.Parameters.AddWithValue("@DeptID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@DeptName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Phone", textBox3.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Saved Sucessfully");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from deptab", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            //SqlCommand cmd = new SqlCommand("update deptab set deptname=@deptname,phone=@phone where deptid=@deptid)", con);
            SqlCommand cmd = new SqlCommand("update deptab set deptname=@deptname, phone=@phone where deptid=@deptid", con);

            cmd.Parameters.AddWithValue("@DeptID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@DeptName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Phone", textBox3.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Updated Sucessfully");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete deptab where deptid=@deptid", con);
            cmd.Parameters.AddWithValue("@DeptID", int.Parse(textBox1.Text));

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Are you sure to delete?");
        }

       

        private void Department_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from deptab", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
