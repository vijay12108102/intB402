using Microsoft.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;
namespace hospitalManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            SqlCommand cmd = new SqlCommand("SELECT Username, Password FROM Logintab WHERE Username = '" + txtUsername.Text + "' AND Password = '" + txtPassword.Text + "'", con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0 )
            {
                Main mn = new Main();
                mn.Show();
            }
            else
            {
                MessageBox.Show("Invaild Username or Password");
            }
            con.Close();
        }
    }
}
