﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace hospitalManagement
{
    public partial class Patient : Form
    {
        public Patient()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into patientab values(@patientid,@patientname,@gender,@email,@address)", con);
            cmd.Parameters.AddWithValue("@patientID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@patientName", textBox2.Text);
            cmd.Parameters.AddWithValue("@gender", textBox3.Text);
            cmd.Parameters.AddWithValue("@email", textBox4.Text);
            cmd.Parameters.AddWithValue("@address", textBox5.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Saved Sucessfully");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from patientab", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update patientab set patientname=@patientname,gender=@gender,email=@email,address=@address where patientid=@patientid", con);
            cmd.Parameters.AddWithValue("@patientID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@patientName", textBox2.Text);
            cmd.Parameters.AddWithValue("@gender", textBox3.Text);
            cmd.Parameters.AddWithValue("@email", textBox4.Text);
            cmd.Parameters.AddWithValue("@address", textBox5.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record updated Sucessfully");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete patientab where patientid=@patientid", con);
            cmd.Parameters.AddWithValue("@patientID", int.Parse(textBox1.Text));

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record deleted Sucessfully");
        }

        private void Patient_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DNBGFJ0\SQLEXPRESS;Initial Catalog=hospitaldb;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from patientab", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
